import React, { useState, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShieldCheck, User, LogIn, CheckCircle, ArrowRight, Lock, 
  LayoutDashboard, FilePlus, LogOut, Bell, 
  AlertTriangle, XCircle, Clock, Calendar, 
  ChevronRight, Upload, FileText, Search, Download,
  Mail, Phone, Briefcase, Building2, UserCircle2, IdCard, MapPin, BadgeCheck,
  Info, FileSearch, ShieldAlert, CheckCircle2, Filter, Eye, EyeOff, Users,
  BarChart3, Settings, MoreVertical, ThumbsUp, ThumbsDown, Plus, Trash2, Edit3, X,
  ClipboardList
} from 'lucide-react';

// --- Types ---
type UserRole = 'employee' | 'admin' | null;
type ActiveView = 'dashboard' | 'upload' | 'profile' | 'employees' | 'review' | 'certificates';
type CertStatus = 'Compliant' | 'Expiring Soon' | 'Expired' | 'Pending Approval';

interface Certificate {
  id: string;
  moduleName: string;
  certNumber: string;
  issueDate: string;
  expiryDate: string;
  fileName: string;
  status: CertStatus;
  employeeId?: string;
  employeeName?: string;
}

interface Employee {
  id: string;
  name: string;
  department: string;
  designation: string;
  email: string;
  phone: string;
  location: string;
  manager: string;
  company: string;
  complianceStatus: 'Compliant' | 'Non-Compliant';
  lastUpdated: string;
}

// --- Utilities ---
const calculateStatus = (expiryDate: string): CertStatus => {
  const today = new Date();
  const expiry = new Date(expiryDate);
  const diffTime = expiry.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return 'Expired';
  if (diffDays <= 60) return 'Expiring Soon';
  return 'Compliant';
};

// --- Mock Data ---
const getDynamicDate = (daysOffset: number) => {
  const date = new Date();
  date.setDate(date.getDate() + daysOffset);
  return date.toISOString().split('T')[0];
};

const INITIAL_CERTS: Certificate[] = [
  {
    id: '1',
    moduleName: 'Equity Derivatives (Series VIII)',
    certNumber: 'NISM-2023-000456',
    issueDate: '2023-01-15',
    expiryDate: getDynamicDate(400),
    fileName: 'cert_derivative.pdf',
    status: 'Compliant'
  },
  {
    id: '2',
    moduleName: 'Mutual Fund Distributors (Series V-A)',
    certNumber: 'NISM-2021-000123',
    issueDate: '2021-05-10',
    expiryDate: getDynamicDate(20),
    fileName: 'mutual_fund.jpg',
    status: 'Expiring Soon'
  },
  {
    id: '3',
    moduleName: 'Securities Operations (Series VII)',
    certNumber: 'NISM-2020-000999',
    issueDate: '2020-02-10',
    expiryDate: getDynamicDate(-10),
    fileName: 'securities_ops.pdf',
    status: 'Expired'
  }
];

const MOCK_EMPLOYEES: Employee[] = [
  { 
    id: 'EMP-7241', 
    name: 'Siddharth Sharma', 
    department: 'Private Wealth Management', 
    designation: 'Senior Wealth Manager', 
    complianceStatus: 'Compliant', 
    email: 'siddharth.sharma@zuarimoney.com', 
    phone: '+91 98765 43210',
    location: 'Mumbai - Corporate Office',
    manager: 'Vikram Aditya Mehta',
    company: 'Zuari Finserv Limited',
    lastUpdated: '2024-03-01' 
  },
  { 
    id: 'EMP-8822', 
    name: 'Anjali Gupta', 
    department: 'Operations', 
    designation: 'Operations Associate', 
    complianceStatus: 'Non-Compliant', 
    email: 'anjali@zuari.com', 
    phone: '+91 98765 43211',
    location: 'Delhi - Branch',
    manager: 'Rajesh Kumar',
    company: 'Zuari Finserv Limited',
    lastUpdated: '2024-02-15' 
  },
  { 
    id: 'EMP-9001', 
    name: 'Rohan Mehra', 
    department: 'Compliance', 
    designation: 'Lead Officer', 
    complianceStatus: 'Compliant', 
    email: 'rohan@zuari.com', 
    phone: '+91 98765 43212',
    location: 'Mumbai - Corporate Office',
    manager: 'Sameer Shah',
    company: 'Zuari Finserv Limited',
    lastUpdated: '2024-03-10' 
  },
  { 
    id: 'EMP-4432', 
    name: 'Priya Iyer', 
    department: 'Sales', 
    designation: 'Relationship Manager', 
    complianceStatus: 'Compliant', 
    email: 'priya@zuari.com', 
    phone: '+91 98765 43213',
    location: 'Bangalore - Branch',
    manager: 'Anita Desai',
    company: 'Zuari Finserv Limited',
    lastUpdated: '2024-01-20' 
  },
];

const PENDING_REVIEWS: Certificate[] = [
  { id: 'rev-1', employeeName: 'Anjali Gupta', employeeId: 'EMP-8822', moduleName: 'Mutual Fund Distributors', certNumber: 'NISM-2024-88', issueDate: '2024-01-01', expiryDate: '2027-01-01', status: 'Pending Approval', fileName: 'mf_cert.pdf' },
  { id: 'rev-2', employeeName: 'Priya Iyer', employeeId: 'EMP-4432', moduleName: 'Equity Derivatives', certNumber: 'NISM-2024-99', issueDate: '2024-02-15', expiryDate: '2027-02-15', status: 'Pending Approval', fileName: 'equity_cert.pdf' },
];

const LOGO_URL = "https://www.zuarimoney.com/App_Themes/images/Zuari_whatsnew2.jpg";
const PROFILE_BANNER_URL = "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2000&auto=format&fit=crop";

const getStatusColor = (status: CertStatus) => {
  switch (status) {
    case 'Compliant': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
    case 'Expiring Soon': return 'text-amber-600 bg-amber-50 border-amber-100';
    case 'Expired': return 'text-rose-600 bg-rose-50 border-rose-100';
    case 'Pending Approval': return 'text-blue-600 bg-blue-50 border-blue-100';
  }
};

// --- Background Components ---
const BackgroundDecoration = () => (
  <div className="fixed inset-0 overflow-hidden pointer-events-none z-0 bg-slate-50">
    <div className="absolute inset-0 opacity-[0.03]" 
         style={{ backgroundImage: 'linear-gradient(#003366 1px, transparent 1px), linear-gradient(90deg, #003366 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
    <svg className="absolute inset-0 w-full h-full opacity-[0.08]" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#003366" stopOpacity="0" />
          <stop offset="50%" stopColor="#003366" stopOpacity="1" />
          <stop offset="100%" stopColor="#003366" stopOpacity="0" />
        </linearGradient>
      </defs>
      {[...Array(6)].map((_, i) => (
        <motion.line
          key={`h-${i}`} x1="0" y1={15 + i * 15 + "%"} x2="100%" y2={15 + i * 15 + "%"}
          stroke="url(#lineGrad)" strokeWidth="1" initial={{ x: "-100%" }} animate={{ x: "100%" }}
          transition={{ duration: 15 + i * 5, repeat: Infinity, ease: "linear", delay: i * 2 }}
        />
      ))}
    </svg>
  </div>
);

// --- Shared Components ---

const StatCard = ({ title, value, icon: Icon, colorClass, isActive, onClick, subtext }: any) => (
  <motion.div 
    whileHover={{ y: -5 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className={`p-6 rounded-2xl shadow-sm border transition-all duration-500 flex flex-col cursor-pointer ${
      isActive 
      ? 'border-slate-100 bg-blue-50/30 shadow-xl transform scale-[1.02]' 
      : 'border-slate-100 bg-white hover:shadow-md'
    }`}
  >
    <div className="flex items-center space-x-4 mb-3">
      <div className={`p-4 rounded-xl ${colorClass}`}>
        <Icon size={24} />
      </div>
      <div>
        <p className="text-slate-500 text-sm font-medium">{title}</p>
        <p className="text-2xl font-bold text-slate-800 tracking-tight">{value}</p>
      </div>
    </div>
    {subtext && <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{subtext}</p>}
  </motion.div>
);

// --- Modals ---

const EmployeeFormModal = ({ isOpen, onClose, onSubmit, employee }: { isOpen: boolean, onClose: () => void, onSubmit: (emp: Partial<Employee>) => void, employee?: Employee }) => {
  const [formData, setFormData] = useState<Partial<Employee>>(employee || {
    name: '', id: '', designation: '', department: '', email: '', phone: '', location: '', manager: '', company: 'Zuari Finserv Limited'
  });

  useEffect(() => {
    if (employee) setFormData(employee);
    else setFormData({ name: '', id: '', designation: '', department: '', email: '', phone: '', location: '', manager: '', company: 'Zuari Finserv Limited' });
  }, [employee, isOpen]);

  if (!isOpen) return null;

  const inputBaseClass = "bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 focus:ring-2 ring-indigo-100 focus:bg-white focus:border-indigo-400 transition-all outline-none placeholder:text-slate-400 shadow-sm";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden"
      >
        <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
          <div>
            <h2 className="text-xl font-black text-slate-800 tracking-tight">{employee ? 'Edit Employee' : 'Add New Employee'}</h2>
            <p className="text-xs text-slate-400 font-medium mt-1">Fill in the professional details below.</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-full transition-colors text-slate-400 hover:text-slate-600 shadow-sm">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={(e) => { e.preventDefault(); onSubmit(formData); }} className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Full Name</label>
              <input required className={inputBaseClass + " w-full"} value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} placeholder="e.g. Siddharth Sharma" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Employee ID</label>
              <input required disabled={!!employee} className={inputBaseClass + " w-full " + (employee ? 'opacity-50 cursor-not-allowed' : '')} value={formData.id} onChange={(e) => setFormData({...formData, id: e.target.value})} placeholder="e.g. EMP-7241" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Designation</label>
              <input required className={inputBaseClass + " w-full"} value={formData.designation} onChange={(e) => setFormData({...formData, designation: e.target.value})} placeholder="e.g. Senior Wealth Manager" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Department</label>
              <select required className={inputBaseClass + " w-full"} value={formData.department} onChange={(e) => setFormData({...formData, department: e.target.value})} >
                <option value="">Select Department</option>
                <option value="Private Wealth Management">Private Wealth Management</option>
                <option value="Operations">Operations</option>
                <option value="Compliance">Compliance</option>
                <option value="Sales">Sales</option>
                <option value="Human Resources">Human Resources</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Corporate Email</label>
              <input required type="email" className={inputBaseClass + " w-full"} value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} placeholder="e.g. siddharth@zuari.com" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Phone Number</label>
              <input required className={inputBaseClass + " w-full"} value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} placeholder="e.g. +91 98765 43210" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Reporting Manager</label>
              <input required className={inputBaseClass + " w-full"} value={formData.manager} onChange={(e) => setFormData({...formData, manager: e.target.value})} placeholder="e.g. Vikram Aditya Mehta" />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Work Location</label>
              <input required className={inputBaseClass + " w-full"} value={formData.location} onChange={(e) => setFormData({...formData, location: e.target.value})} placeholder="e.g. Mumbai - Corporate Office" />
            </div>
          </div>
          <div className="pt-6 flex items-center space-x-4 border-t border-slate-50">
            <button type="button" onClick={onClose} className="px-6 py-4 bg-slate-100 text-slate-500 rounded-2xl font-bold text-sm hover:bg-slate-200 transition-all">Cancel</button>
            <button type="submit" className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-sm uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">{employee ? 'Save Changes' : 'Create Employee Profile'}</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

// --- Views ---

const ProfileView = ({ employee }: { employee: Employee }) => {
  const detailItems = [
    { icon: IdCard, label: 'Employee ID', value: employee.id },
    { icon: User, label: 'Employee Name', value: employee.name },
    { icon: UserCircle2, label: 'Manager Name', value: employee.manager },
    { icon: Building2, label: 'Curr. Company', value: employee.company },
    { icon: Mail, label: 'Email Address', value: employee.email },
    { icon: Phone, label: 'Phone Number', value: employee.phone },
  ];

  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-4xl mx-auto">
      <div className="bg-white rounded-[3rem] shadow-2xl shadow-blue-900/5 border border-slate-100 overflow-hidden relative">
        <div className="h-56 relative overflow-hidden bg-slate-900" style={{ backgroundImage: `url(${PROFILE_BANNER_URL})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute inset-0 bg-blue-900/20 mix-blend-multiply" />
        </div>
        <div className="px-12 pb-16 relative">
          <div className="relative -mt-24 mb-10 flex flex-col items-center">
            <div className="relative p-2 bg-white rounded-[2.5rem] shadow-xl border border-slate-50">
              <div className="w-40 h-40 rounded-[2rem] bg-gradient-to-br from-blue-500 to-indigo-700 flex items-center justify-center text-white overflow-hidden relative">
                <User size={80} strokeWidth={1.5} />
              </div>
            </div>
            <div className="mt-6 text-center">
              <h2 className="text-3xl font-black text-slate-800 tracking-tight">{employee.name}</h2>
              <div className="flex items-center justify-center space-x-2 mt-1">
                <span className="text-blue-600 font-bold uppercase text-xs tracking-widest">{employee.designation}</span>
                <span className="w-1.5 h-1.5 bg-slate-300 rounded-full" />
                <span className="text-slate-400 font-medium text-xs">{employee.department}</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
            {detailItems.map((item, idx) => (
              <div key={idx} className="flex items-start space-x-4 group">
                <div className="p-3 bg-slate-50 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 rounded-2xl transition-all duration-300">
                  <item.icon size={20} />
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-[0.15em] text-slate-400 mb-0.5">{item.label}</label>
                  <p className="text-slate-800 font-bold group-hover:text-blue-900 transition-colors">{item.value}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// --- Main Portal Components ---

const EmployeePortal = ({ onLogout }: { onLogout: () => void }) => {
  const [view, setView] = useState<ActiveView>('dashboard');
  const [certs, setCerts] = useState<Certificate[]>(INITIAL_CERTS);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<CertStatus | 'All'>('All');
  
  const currentEmployee = MOCK_EMPLOYEES[0];

  const stats = useMemo(() => ({
    total: certs.length,
    compliant: certs.filter(c => c.status === 'Compliant').length,
    expiring: certs.filter(c => c.status === 'Expiring Soon').length,
    expired: certs.filter(c => c.status === 'Expired').length,
  }), [certs]);

  const filteredCerts = useMemo(() => {
    return certs.filter(c => {
      const matchesSearch = c.moduleName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            c.certNumber.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [certs, searchTerm, statusFilter]);

  const handleUpload = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const newCert: Certificate = {
      id: Math.random().toString(36).substr(2, 9),
      moduleName: formData.get('module') as string,
      certNumber: formData.get('certNumber') as string,
      issueDate: formData.get('issueDate') as string,
      expiryDate: formData.get('expiryDate') as string,
      fileName: 'new_upload.pdf',
      status: calculateStatus(formData.get('expiryDate') as string)
    };
    setCerts([newCert, ...certs]);
    setView('dashboard');
  };

  const inputBaseClass = "bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 focus:ring-2 ring-blue-100 focus:bg-white focus:border-blue-300 transition-all outline-none placeholder:text-slate-400 shadow-sm";

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <motion.aside initial={{ x: -250 }} animate={{ x: 0 }} className="w-72 bg-white border-r border-slate-100 flex flex-col z-20">
        <div className="border-b border-slate-50 bg-white">
          <img src={LOGO_URL} alt="Logo" className="w-full h-24 object-contain block" />
        </div>
        <nav className="flex-1 p-6 space-y-2">
          <button onClick={() => setView('dashboard')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === 'dashboard' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}>
            <LayoutDashboard size={20} /><span>My Dashboard</span>
          </button>
          <button onClick={() => setView('upload')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === 'upload' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}>
            <FilePlus size={20} /><span>Upload Certificate</span>
          </button>
          <button onClick={() => setView('profile')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === 'profile' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}>
            <UserCircle2 size={20} /><span>My Profile</span>
          </button>
        </nav>
        <div className="p-6 border-t border-slate-50">
          <button onClick={onLogout} className="w-full flex items-center justify-center space-x-2 px-4 py-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors font-bold text-sm">
            <LogOut size={16} /><span>Logout</span>
          </button>
        </div>
      </motion.aside>

      <main className="flex-1 relative overflow-y-auto">
        <BackgroundDecoration />
        <div className="relative z-10 p-10 max-w-7xl mx-auto">
          <header className="flex justify-between items-center mb-10">
            <div>
              <h1 className="text-3xl font-black text-slate-800 tracking-tight">
                {view === 'dashboard' ? 'Compliance Overview' : 
                 view === 'upload' ? 'Upload Certification' : 'Employee Profile'}
              </h1>
              <p className="text-slate-500 mt-1 font-medium tracking-tight">Portal: {currentEmployee.name} • Zuari Finserv Ltd</p>
            </div>
          </header>

          <AnimatePresence mode="wait">
            {view === 'dashboard' && (
              <motion.div key="dashboard" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <StatCard title="Total Modules" value={stats.total} icon={FileText} colorClass="bg-blue-50 text-blue-600" isActive={statusFilter === 'All'} onClick={() => setStatusFilter('All')} />
                  <StatCard title="Compliant" value={stats.compliant} icon={CheckCircle} colorClass="bg-emerald-50 text-emerald-600" isActive={statusFilter === 'Compliant'} onClick={() => setStatusFilter('Compliant')} />
                  <StatCard title="Expiring Soon" value={stats.expiring} icon={Clock} colorClass="bg-amber-50 text-amber-600" isActive={statusFilter === 'Expiring Soon'} onClick={() => setStatusFilter('Expiring Soon')} />
                  <StatCard title="Expired" value={stats.expired} icon={XCircle} colorClass="bg-rose-50 text-rose-600" isActive={statusFilter === 'Expired'} onClick={() => setStatusFilter('Expired')} />
                </div>

                <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
                  <div className="p-6 border-b border-slate-50 flex flex-col xl:flex-row xl:items-center justify-between gap-6">
                    <h2 className="text-xl font-bold text-slate-800">My Certificates</h2>
                    <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4">
                      <div className="relative flex-1 md:w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input type="text" placeholder="Search by module..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className={`${inputBaseClass} pl-10 w-full`} />
                      </div>
                      <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as any)} className={`${inputBaseClass} w-full md:w-48 cursor-pointer font-medium text-slate-600`}>
                        <option value="All">All Statuses</option>
                        <option value="Compliant">Compliant Only</option>
                        <option value="Expiring Soon">Expiring Soon</option>
                        <option value="Expired">Expired Only</option>
                      </select>
                    </div>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50/50">
                        <tr>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Module Name</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cert Number</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Expiry Date</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {filteredCerts.map((cert) => (
                          <tr key={cert.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-4 text-sm font-bold text-slate-700">{cert.moduleName}</td>
                            <td className="px-6 py-4 text-xs font-medium text-slate-500">{cert.certNumber}</td>
                            <td className="px-6 py-4 text-sm font-medium text-slate-600">{new Date(cert.expiryDate).toLocaleDateString()}</td>
                            <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${getStatusColor(cert.status)}`}>{cert.status}</span></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {view === 'upload' && (
              <motion.div key="upload" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                <div className="lg:col-span-7">
                  <div className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-8 text-blue-50/50 pointer-events-none"><Upload size={120} /></div>
                    <form onSubmit={handleUpload} className="space-y-6 relative z-10">
                      <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">NISM Module</label>
                        <select name="module" required className={`${inputBaseClass} w-full`}>
                          <option value="">Select Module</option>
                          <option value="Equity Derivatives (Series VIII)">Equity Derivatives (Series VIII)</option>
                          <option value="Mutual Fund Distributors (Series V-A)">Mutual Fund Distributors (Series V-A)</option>
                          <option value="Investment Adviser (Series X-A/X-B)">Investment Adviser (Series X-A/X-B)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-slate-700 mb-2">Certificate Number</label>
                        <input name="certNumber" required type="text" placeholder="NISM-2024-XXXXX" className={`${inputBaseClass} w-full`} />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><label className="block text-sm font-bold text-slate-700 mb-2">Issue Date</label><input name="issueDate" required type="date" className={`${inputBaseClass} w-full`} /></div>
                        <div><label className="block text-sm font-bold text-slate-700 mb-2">Expiry Date</label><input name="expiryDate" required type="date" className={`${inputBaseClass} w-full`} /></div>
                      </div>
                      <div className="pt-4">
                        <label className="block text-sm font-bold text-slate-700 mb-2">Upload Document (PDF/JPG)</label>
                        <div className="border-2 border-dashed border-slate-100 rounded-2xl p-8 flex flex-col items-center justify-center hover:bg-slate-50 transition-colors cursor-pointer group">
                          <Upload size={32} className="text-slate-300 mb-3 group-hover:text-blue-500 transition-colors" />
                          <p className="text-sm text-slate-400 font-medium text-center">Click to browse or drag and drop file</p>
                          <p className="text-[10px] text-slate-300 mt-1 uppercase font-bold tracking-wider">Max size 5MB</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 pt-6">
                        <button type="submit" className="flex-1 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold transition-all shadow-lg shadow-blue-100 uppercase tracking-widest text-sm">Register Certificate</button>
                        <button type="button" onClick={() => setView('dashboard')} className="px-8 py-4 bg-slate-100 text-slate-500 rounded-2xl font-bold hover:bg-slate-200 transition-all">Cancel</button>
                      </div>
                    </form>
                  </div>
                </div>

                <div className="lg:col-span-5 space-y-8">
                  <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
                    <div className="flex items-center space-x-3 mb-6">
                      <div className="p-2 bg-blue-50 text-blue-600 rounded-lg"><Info size={20} /></div>
                      <h3 className="text-lg font-bold text-slate-800">Upload Guidelines</h3>
                    </div>
                    <ul className="space-y-4">
                      <li className="flex items-start space-x-3">
                        <CheckCircle2 size={16} className="text-emerald-500 mt-1 flex-shrink-0" />
                        <p className="text-sm text-slate-500 leading-relaxed"><span className="font-bold text-slate-700">File Format:</span> Only PDF or JPG scans are accepted.</p>
                      </li>
                      <li className="flex items-start space-x-3">
                        <CheckCircle2 size={16} className="text-emerald-500 mt-1 flex-shrink-0" />
                        <p className="text-sm text-slate-500 leading-relaxed"><span className="font-bold text-slate-700">Legibility:</span> Ensure the Certificate Number and Expiry Date are visible.</p>
                      </li>
                    </ul>
                  </motion.div>

                  <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }} className="bg-gradient-to-br from-slate-800 to-slate-900 p-8 rounded-[2rem] text-white shadow-xl relative overflow-hidden">
                    <div className="absolute -bottom-4 -right-4 text-white/5 rotate-12"><ShieldCheck size={160} /></div>
                    <h3 className="text-lg font-bold mb-6 relative z-10">Verification Journey</h3>
                    <div className="space-y-6 relative z-10">
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-xs font-black">1</div>
                        <div><p className="text-sm font-bold">Document Upload</p><p className="text-[11px] text-slate-400">Securely stored in cloud</p></div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-black">2</div>
                        <div><p className="text-sm font-bold">Verification Process</p><p className="text-[11px] text-slate-400">Validation against NISM data</p></div>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            )}

            {view === 'profile' && <ProfileView employee={currentEmployee} />}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

const AdminPortal = ({ onLogout }: { onLogout: () => void }) => {
  const [view, setView] = useState<ActiveView>('dashboard');
  const [employees, setEmployees] = useState<Employee[]>(MOCK_EMPLOYEES);
  const [reviews, setReviews] = useState<Certificate[]>(PENDING_REVIEWS);
  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('All');
  const [certSearchTerm, setCertSearchTerm] = useState('');
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | undefined>(undefined);

  // Aggregated certificates for the organization
  const allCertificates = useMemo(() => {
    const orgCerts: Certificate[] = [];
    employees.forEach(emp => {
      if (emp.id === 'EMP-7241') {
        INITIAL_CERTS.forEach(c => orgCerts.push({ ...c, employeeId: emp.id, employeeName: emp.name }));
      }
    });
    return orgCerts;
  }, [employees]);

  const filteredCertificates = useMemo(() => {
    return allCertificates.filter(c => 
      c.moduleName.toLowerCase().includes(certSearchTerm.toLowerCase()) || 
      c.certNumber.toLowerCase().includes(certSearchTerm.toLowerCase()) ||
      c.employeeName?.toLowerCase().includes(certSearchTerm.toLowerCase())
    );
  }, [allCertificates, certSearchTerm]);

  const adminStats = useMemo(() => ({
    totalEmployees: employees.length,
    complianceRate: `${Math.round((employees.filter(e => e.complianceStatus === 'Compliant').length / employees.length) * 100)}%`,
    pendingReviews: reviews.length,
    criticalExpirations: 5
  }), [employees, reviews]);

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchesSearch = emp.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           emp.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDept = deptFilter === 'All' || emp.department === deptFilter;
      return matchesSearch && matchesDept;
    });
  }, [employees, searchTerm, deptFilter]);

  const handleReviewAction = (id: string, action: 'approve' | 'reject') => {
    setReviews(reviews.filter(r => r.id !== id));
  };

  const handleDeleteEmployee = (id: string) => {
    if (confirm('Are you sure you want to delete this employee? This action cannot be undone.')) {
      setEmployees(employees.filter(e => e.id !== id));
    }
  };

  const handleEmployeeSubmit = (data: Partial<Employee>) => {
    if (editingEmployee) {
      setEmployees(employees.map(e => e.id === editingEmployee.id ? { ...e, ...data } as Employee : e));
    } else {
      const newEmp: Employee = {
        ...data as Employee,
        complianceStatus: 'Non-Compliant',
        lastUpdated: new Date().toISOString().split('T')[0]
      };
      setEmployees([newEmp, ...employees]);
    }
    setIsModalOpen(false);
    setEditingEmployee(undefined);
  };

  const inputBaseClass = "bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 focus:ring-2 ring-indigo-100 focus:bg-white focus:border-indigo-300 transition-all outline-none placeholder:text-slate-400 shadow-sm";

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <motion.aside initial={{ x: -250 }} animate={{ x: 0 }} className="w-72 bg-white border-r border-slate-100 flex flex-col z-20">
        <div className="p-8 border-b border-slate-50">
          <img src={LOGO_URL} alt="Logo" className="w-full h-12 object-contain" />
          <div className="mt-4 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full inline-block">
            <span className="text-[10px] font-black uppercase tracking-widest">Admin Control</span>
          </div>
        </div>
        <nav className="flex-1 p-6 space-y-2">
          <button onClick={() => setView('dashboard')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === 'dashboard' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}>
            <LayoutDashboard size={20} /><span>Admin Dashboard</span>
          </button>
          <button onClick={() => setView('employees')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === 'employees' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}>
            <Users size={20} /><span>Workforce Directory</span>
          </button>
          <button onClick={() => setView('certificates')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === 'certificates' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}>
            <ClipboardList size={20} /><span>All Certificates</span>
          </button>
          <button onClick={() => setView('review')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${view === 'review' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-50'}`}>
            <div className="relative"><ShieldCheck size={20} />{reviews.length > 0 && <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full" />}</div>
            <span>Review Queue</span>
          </button>
        </nav>
        <div className="p-6 border-t border-slate-50">
          <button onClick={onLogout} className="w-full flex items-center justify-center space-x-2 px-4 py-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors font-bold text-sm">
            <LogOut size={16} /><span>Logout Admin</span>
          </button>
        </div>
      </motion.aside>

      <main className="flex-1 relative overflow-y-auto">
        <BackgroundDecoration />
        <div className="relative z-10 p-10 max-w-7xl mx-auto">
          <header className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl font-black text-slate-800 tracking-tight">
                {view === 'dashboard' ? 'Organization Insights' : 
                 view === 'employees' ? 'Workforce Directory' : 
                 view === 'certificates' ? 'Certificates Repository' :
                 view === 'review' ? 'Verification Queue' : 'Admin Profile'}
              </h1>
              <p className="text-slate-500 mt-1 font-medium tracking-tight">Managing compliance for Zuari Finserv Ltd</p>
            </div>
            {view === 'employees' && (
              <button onClick={() => { setEditingEmployee(undefined); setIsModalOpen(true); }} className="bg-indigo-600 text-white px-6 py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center space-x-2">
                <Plus size={18} /><span>Add Employee</span>
              </button>
            )}
            {view === 'certificates' && (
              <button className="bg-emerald-600 text-white px-6 py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-emerald-100 hover:bg-emerald-700 transition-all flex items-center space-x-2">
                <Download size={18} /><span>Export All</span>
              </button>
            )}
          </header>

          <AnimatePresence mode="wait">
            {view === 'dashboard' && (
              <motion.div key="admin-dash" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <StatCard title="Total Employees" value={adminStats.totalEmployees} icon={Users} colorClass="bg-indigo-50 text-indigo-600" subtext="Across all offices" />
                  <StatCard title="Compliance Rate" value={adminStats.complianceRate} icon={BarChart3} colorClass="bg-emerald-50 text-emerald-600" subtext="Target: 95%" />
                  <StatCard title="Pending Review" value={adminStats.pendingReviews} icon={Clock} colorClass="bg-blue-50 text-blue-600" subtext="Action required" onClick={() => setView('review')} />
                  <StatCard title="Critical Expirations" value={adminStats.criticalExpirations} icon={ShieldAlert} colorClass="bg-rose-50 text-rose-600" subtext="Next 30 days" />
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
                    <h3 className="text-lg font-bold text-slate-800 mb-6">Department Compliance</h3>
                    <div className="space-y-6">
                      {[{ dept: 'Private Wealth', val: 92, color: 'bg-blue-500' }, { dept: 'Operations', val: 78, color: 'bg-indigo-500' }, { dept: 'Compliance', val: 100, color: 'bg-emerald-500' }, { dept: 'Sales', val: 84, color: 'bg-amber-500' }].map((d, i) => (
                        <div key={i} className="space-y-2">
                          <div className="flex justify-between text-xs font-bold uppercase tracking-wider"><span className="text-slate-500">{d.dept}</span><span className="text-slate-800">{d.val}%</span></div>
                          <div className="h-2 w-full bg-slate-50 rounded-full overflow-hidden"><motion.div initial={{ width: 0 }} animate={{ width: `${d.val}%` }} transition={{ duration: 1, delay: i * 0.1 }} className={`h-full ${d.color}`} /></div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="bg-slate-900 p-8 rounded-[2rem] text-white shadow-xl relative overflow-hidden flex flex-col justify-between">
                    <div className="absolute top-0 right-0 p-8 opacity-10"><ShieldCheck size={120} /></div>
                    <div><h3 className="text-xl font-black mb-2 uppercase tracking-tight">Compliance Scorecard</h3><p className="text-slate-400 text-sm">Your organization is currently performing better than 84% of industry peers.</p></div>
                    <div className="mt-8 pt-8 border-t border-slate-800"><button className="w-full py-4 bg-white/5 hover:bg-white/10 rounded-xl font-bold transition-all text-xs uppercase tracking-widest flex items-center justify-center space-x-2"><span>Generate Audit Report</span><Download size={14} /></button></div>
                  </div>
                </div>
              </motion.div>
            )}

            {view === 'employees' && (
              <motion.div key="admin-employees" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-50 flex flex-col xl:flex-row xl:items-center justify-between gap-6">
                  <h2 className="text-xl font-bold text-slate-800">Workforce Status</h2>
                  <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4">
                    <div className="relative w-full md:w-64">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input type="text" placeholder="Search employee..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className={`${inputBaseClass} pl-10 w-full`} />
                    </div>
                    <select 
                      value={deptFilter} 
                      onChange={(e) => setDeptFilter(e.target.value)} 
                      className={`${inputBaseClass} w-full md:w-56 cursor-pointer font-medium text-slate-600`}
                    >
                      <option value="All">All Departments</option>
                      <option value="Private Wealth Management">Private Wealth Management</option>
                      <option value="Operations">Operations</option>
                      <option value="Compliance">Compliance</option>
                      <option value="Sales">Sales</option>
                      <option value="Human Resources">Human Resources</option>
                    </select>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50/50">
                      <tr><th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Employee</th><th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Department</th><th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th><th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">Actions</th></tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {filteredEmployees.map((emp) => (
                        <tr key={emp.id} className="hover:bg-slate-50/50 transition-colors group">
                          <td className="px-6 py-4">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-500 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-all shadow-sm"><User size={20} /></div>
                              <div><p className="text-sm font-bold text-slate-800">{emp.name}</p><p className="text-[10px] text-slate-400 font-bold tracking-wider">{emp.id}</p></div>
                            </div>
                          </td>
                          <td className="px-6 py-4"><p className="text-xs font-bold text-slate-600 tracking-tight">{emp.department}</p><p className="text-[10px] text-slate-400">{emp.designation}</p></td>
                          <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${emp.complianceStatus === 'Compliant' ? 'text-emerald-600 bg-emerald-50 border-emerald-100' : 'text-rose-600 bg-rose-50 border-rose-100'}`}>{emp.complianceStatus}</span></td>
                          <td className="px-6 py-4"><div className="flex items-center justify-center space-x-2"><button onClick={() => { setEditingEmployee(emp); setIsModalOpen(true); }} className="p-2 text-indigo-600 bg-indigo-50 hover:bg-indigo-600 hover:text-white rounded-xl transition-all shadow-sm"><Edit3 size={16} /></button><button onClick={() => handleDeleteEmployee(emp.id)} className="p-2 text-rose-500 bg-rose-50 hover:bg-rose-500 hover:text-white rounded-xl transition-all shadow-sm"><Trash2 size={16} /></button></div></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {filteredEmployees.length === 0 && (
                    <div className="py-20 text-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                        <Users size={32} />
                      </div>
                      <p className="text-slate-500 font-medium">No employees found matching these criteria.</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {view === 'certificates' && (
              <motion.div key="admin-certs" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
                <div className="p-6 border-b border-slate-50 flex justify-between items-center">
                  <h2 className="text-xl font-bold text-slate-800">Organizational Certifications</h2>
                  <div className="relative w-72">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input type="text" placeholder="Search by name, module or cert #..." value={certSearchTerm} onChange={(e) => setCertSearchTerm(e.target.value)} className={`${inputBaseClass} pl-10 w-full`} />
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50/50">
                      <tr>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Employee</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Module</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Certificate #</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Expiry</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">File</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {filteredCertificates.map((cert) => (
                        <tr key={cert.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4">
                            <p className="text-sm font-bold text-slate-800">{cert.employeeName}</p>
                            <p className="text-[10px] text-slate-400 font-bold">{cert.employeeId}</p>
                          </td>
                          <td className="px-6 py-4">
                            <p className="text-sm font-medium text-slate-700">{cert.moduleName}</p>
                          </td>
                          <td className="px-6 py-4 text-xs font-bold text-slate-500">{cert.certNumber}</td>
                          <td className="px-6 py-4 text-sm font-medium text-slate-600">{new Date(cert.expiryDate).toLocaleDateString()}</td>
                          <td className="px-6 py-4">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider border ${getStatusColor(cert.status)}`}>
                              {cert.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <button className="p-2 text-indigo-600 bg-indigo-50 hover:bg-indigo-600 hover:text-white rounded-xl transition-all shadow-sm" title="Download Document">
                              <Download size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {view === 'review' && (
              <motion.div key="admin-review" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                {reviews.length === 0 ? (<div className="bg-white p-20 rounded-[2.5rem] text-center border border-slate-100"><div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-6 text-emerald-500"><CheckCircle size={40} /></div><h3 className="text-xl font-bold text-slate-800">Queue is Clear</h3><p className="text-slate-500 mt-2">All pending NISM certifications have been reviewed.</p></div>) : (
                  reviews.map((rev) => (
                    <motion.div layout key={rev.id} className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col lg:flex-row items-center justify-between gap-8">
                      <div className="flex items-start space-x-6">
                        <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 flex-shrink-0"><FileText size={32} /></div>
                        <div>
                          <div className="flex items-center space-x-2 mb-1"><h4 className="text-lg font-bold text-slate-800">{rev.moduleName}</h4><span className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[9px] font-black uppercase rounded-full border border-blue-100">Pending Review</span></div>
                          <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-xs"><p className="text-slate-400 font-bold uppercase tracking-wider">Employee: <span className="text-slate-800">{rev.employeeName} ({rev.employeeId})</span></p><p className="text-slate-400 font-bold uppercase tracking-wider">Cert #: <span className="text-slate-800">{rev.certNumber}</span></p></div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <button className="flex items-center space-x-2 px-6 py-3 bg-slate-50 text-slate-500 hover:bg-slate-100 rounded-xl font-bold text-xs uppercase tracking-widest transition-all">
                          <Eye size={16} /><span>Preview</span>
                        </button>
                        <button className="flex items-center space-x-2 px-6 py-3 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-xl font-bold text-xs uppercase tracking-widest transition-all" title="Download Document">
                          <Download size={16} /><span>Download</span>
                        </button>
                        <button onClick={() => handleReviewAction(rev.id, 'reject')} className="p-3 text-rose-500 hover:bg-rose-50 rounded-xl transition-all"><ThumbsDown size={20} /></button>
                        <button onClick={() => handleReviewAction(rev.id, 'approve')} className="flex items-center space-x-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"><ThumbsUp size={16} /><span>Approve</span></button>
                      </div>
                    </motion.div>
                  ))
                )}
              </motion.div>
            )}

            {view === 'profile' && <ProfileView employee={MOCK_EMPLOYEES[2]} />}
          </AnimatePresence>
        </div>
      </main>

      <EmployeeFormModal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setEditingEmployee(undefined); }} onSubmit={handleEmployeeSubmit} employee={editingEmployee} />
    </div>
  );
};

// --- Login Page ---

const LoginPage = ({ onLogin }: { onLogin: (role: UserRole) => void }) => {
  const [isLoggingIn, setIsLoggingIn] = useState<UserRole>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleFormLogin = (e: React.FormEvent) => { e.preventDefault(); setIsLoggingIn('employee'); setTimeout(() => onLogin('employee'), 1800); };
  const handleQuickLogin = (role: UserRole) => { setIsLoggingIn(role); setTimeout(() => onLogin(role), 1800); };
  const inputClass = "w-full bg-slate-50 border border-slate-200 rounded-2xl px-12 py-4 text-sm text-slate-900 focus:ring-2 ring-blue-100 focus:bg-white focus:border-blue-400 transition-all outline-none placeholder:text-slate-400 shadow-sm";

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-slate-50">
      <BackgroundDecoration />
      <motion.div initial={{ opacity: 0, y: 40, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }} className="w-full max-w-lg p-10 glass-effect rounded-[3rem] shadow-[0_40px_80px_-15px_rgba(0,51,102,0.1)] z-10 mx-4 border border-white relative overflow-hidden">
        <div className="flex flex-col items-center mb-10 relative">
          <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ delay: 0.2 }} className="mb-6 w-48"><img src={LOGO_URL} alt="Logo" className="w-full h-auto object-contain block mx-auto" /></motion.div>
          <div className="text-center"><h1 className="text-2xl font-black zuari-blue tracking-tighter leading-none mb-2">NISM Compliance</h1><p className="text-slate-400 text-[10px] font-bold tracking-[0.2em] uppercase">Secured Enterprise Access</p></div>
        </div>
        <AnimatePresence mode="wait">
          {!isLoggingIn ? (
            <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <form onSubmit={handleFormLogin} className="space-y-6">
                <div className="relative group"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={20} /><input type="email" placeholder="Corporate Email" value={email} onChange={(e) => setEmail(e.target.value)} required className={inputClass} /></div>
                <div className="relative group"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors" size={20} /><input type={showPassword ? "text" : "password"} placeholder="Account Password" value={password} onChange={(e) => setPassword(e.target.value)} required className={inputClass} /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 transition-colors">{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></div>
                <div className="flex justify-end"><button type="button" className="text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors">Forgot Password?</button></div>
                <motion.button whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }} type="submit" className="w-full py-5 bg-gradient-to-r from-blue-700 to-blue-900 text-white rounded-[2rem] font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-900/20 hover:shadow-blue-900/40 transition-all flex items-center justify-center space-x-3"><span>Login to Portal</span><ArrowRight size={18} /></motion.button>
              </form>
              <div className="flex items-center my-10"><div className="flex-1 h-px bg-slate-100" /><span className="px-4 text-[10px] font-bold text-slate-300 uppercase tracking-widest">Quick Access (Demo)</span><div className="flex-1 h-px bg-slate-100" /></div>
              <div className="grid grid-cols-2 gap-4">
                <button onClick={() => handleQuickLogin('employee')} className="flex items-center justify-center space-x-2 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-slate-500 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition-all font-bold text-[11px] uppercase tracking-wider"><User size={14} /><span>Employee</span></button>
                <button onClick={() => handleQuickLogin('admin')} className="flex items-center justify-center space-x-2 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-slate-500 hover:bg-indigo-50 hover:border-indigo-200 hover:text-indigo-600 transition-all font-bold text-[11px] uppercase tracking-wider"><ShieldCheck size={14} /><span>Admin</span></button>
              </div>
            </motion.div>
          ) : (<motion.div key="loading" className="flex flex-col items-center justify-center py-10"><div className="relative w-24 h-24 mb-8"><svg className="absolute inset-0 w-full h-full rotate-[-90deg]"><motion.circle initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 1.5 }} cx="48" cy="48" r="44" strokeWidth="4" stroke={isLoggingIn === 'admin' ? '#4f46e5' : '#2563eb'} fill="none" strokeLinecap="round" /><circle cx="48" cy="48" r="44" strokeWidth="4" stroke="#f1f5f9" fill="none" /></svg><div className="absolute inset-0 flex items-center justify-center"><motion.div animate={{ rotateY: 360 }} transition={{ repeat: Infinity, duration: 2, ease: "linear" }}><ShieldCheck size={36} className={isLoggingIn === 'admin' ? 'text-indigo-600' : 'text-blue-600'} /></motion.div></div></div><h2 className="text-xl font-black text-slate-800 uppercase tracking-widest">Verifying</h2><p className="text-xs text-slate-400 mt-2 font-medium tracking-wide">Establishing session...</p></motion.div>)}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

const MainApp = () => {
  const [role, setRole] = useState<UserRole>(null);
  if (role === 'employee') return <EmployeePortal onLogout={() => setRole(null)} />;
  if (role === 'admin') return <AdminPortal onLogout={() => setRole(null)} />;
  return <LoginPage onLogin={setRole} />;
};

const root = createRoot(document.getElementById('root')!);
root.render(<MainApp />);